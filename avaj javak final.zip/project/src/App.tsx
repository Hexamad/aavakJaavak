import React, { useState } from 'react';
import { Settings as SettingsIcon, Edit, Share } from 'lucide-react';
import EditBusinessName from './components/EditBusinessName';
import EditPaymentDetails from './components/EditPaymentDetails';
import Settings from './components/Settings';
import PaymentHistory from './components/PaymentHistory';
import ChopdaCalendar from './components/ChopdaCalendar';
import Reports from './components/Reports';

function App() {
  const [activeTab, setActiveTab] = useState('customers');
  const [businessName, setBusinessName] = useState('My Business');
  const [isEditing, setIsEditing] = useState(false);
  const [isEditingPayment, setIsEditingPayment] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isPaymentHistoryOpen, setIsPaymentHistoryOpen] = useState(false);
  const [isChopdaCalendarOpen, setIsChopdaCalendarOpen] = useState(false);
  const [isReportsOpen, setIsReportsOpen] = useState(false);

  return (
    <>
      {isReportsOpen ? (
        <Reports
          onClose={() => setIsReportsOpen(false)}
        />
      ) : isChopdaCalendarOpen ? (
        <ChopdaCalendar
          onClose={() => setIsChopdaCalendarOpen(false)}
          onNavigateToReports={() => {
            setIsChopdaCalendarOpen(false);
            setIsReportsOpen(true);
          }}
        />
      ) : isPaymentHistoryOpen ? (
        <PaymentHistory
          onClose={() => setIsPaymentHistoryOpen(false)}
        />
      ) : isSettingsOpen ? (
        <Settings
          onClose={() => setIsSettingsOpen(false)}
          onNavigateToPaymentHistory={() => {
            setIsSettingsOpen(false);
            setIsPaymentHistoryOpen(true);
          }}
          onNavigateToChopdaCalendar={() => {
            setIsSettingsOpen(false);
            setIsChopdaCalendarOpen(true);
          }}
        />
      ) : isEditingPayment ? (
        <EditPaymentDetails
          onClose={() => setIsEditingPayment(false)}
          onSave={(details) => {
            console.log('Payment details:', details);
            setIsEditingPayment(false);
          }}
        />
      ) : isEditing ? (
        <EditBusinessName
          currentName={businessName}
          onClose={() => setIsEditing(false)}
          onSave={(newName) => {
            setBusinessName(newName);
            setIsEditing(false);
          }}
        />
      ) : (
        <div className="min-h-screen bg-[#121212] text-white p-4">
          {/* Header */}
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-bold">{businessName}</h1>
            <div className="flex gap-4">
              <button 
                className="hover:opacity-80 transition-opacity"
                onClick={() => setIsEditing(true)}
              >
                <Edit size={20} />
              </button>
              <button 
                className="hover:opacity-80 transition-opacity"
                onClick={() => setIsSettingsOpen(true)}
              >
                <SettingsIcon size={20} />
              </button>
            </div>
          </div>

          {/* Tab Navigation */}
          <div className="flex gap-6 mb-6 border-b border-gray-700">
            <button
              className={`pb-2 px-1 ${
                activeTab === 'customers'
                  ? 'border-b-2 border-white font-medium'
                  : 'text-gray-400'
              }`}
              onClick={() => setActiveTab('customers')}
            >
              Customers
            </button>
            <button
              className={`pb-2 px-1 ${
                activeTab === 'suppliers'
                  ? 'border-b-2 border-white font-medium'
                  : 'text-gray-400'
              }`}
              onClick={() => setActiveTab('suppliers')}
            >
              Suppliers
            </button>
          </div>

          {/* Cards Grid */}
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="bg-[#1E1E1E] p-4 rounded-xl">
              <p className="text-xl font-semibold text-red-500">₹0</p>
              <p className="text-sm text-gray-400">You will give</p>
            </div>
            <div className="bg-[#1E1E1E] p-4 rounded-xl">
              <p className="text-xl font-semibold text-green-500">₹0</p>
              <p className="text-sm text-gray-400">You will get</p>
            </div>
            <div 
              className="bg-[#1E1E1E] p-4 rounded-xl col-span-2 cursor-pointer hover:bg-[#252525] transition-colors"
              onClick={() => setIsEditingPayment(true)}
            >
              <p className="text-xl font-semibold">₹0</p>
              <p className="text-sm text-gray-400">QR Collections</p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-4">
            <button 
              className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-blue-700 active:bg-blue-800 transition-colors"
              onClick={() => setIsReportsOpen(true)}
            >
              View Reports
            </button>
            <button className="flex-1 bg-gray-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-gray-700 active:bg-gray-800 transition-colors flex items-center justify-center gap-2">
              <Share size={18} />
              Share
            </button>
          </div>
        </div>
      )}
    </>
  );
}

export default App;