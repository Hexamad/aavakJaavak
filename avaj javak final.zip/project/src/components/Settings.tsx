import React, { useState } from 'react';
import { 
  ArrowLeft, 
  ChevronRight, 
  History, 
  User, 
  Bell, 
  Lock, 
  Calendar,
  Languages,
  Moon,
  Sun,
  HelpCircle,
  LogOut,
  CreditCard,
  AlertTriangle,
  Settings as SettingsIcon,
  Mail,
  Phone,
  Camera,
  DollarSign
} from 'lucide-react';

interface SettingsProps {
  onClose: () => void;
  onNavigateToPaymentHistory: () => void;
  onNavigateToChopdaCalendar: () => void;
}

interface Loan {
  id: string;
  name: string;
  amount: number;
  dueDate: string;
  interestRate: number;
  status: 'active' | 'paid';
}

function AccountDetailsModal({ onClose }: { onClose: () => void }) {
  const [profileImage, setProfileImage] = useState<string | null>(null);

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[#1E1E1E] w-full max-w-md rounded-lg overflow-hidden">
        <div className="p-4 border-b border-gray-800 flex items-center">
          <button 
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-gray-800 active:bg-gray-700 transition-colors"
          >
            <ArrowLeft size={18} />
          </button>
          <h3 className="text-lg font-medium ml-3">Account Details</h3>
        </div>
        
        <div className="p-4 space-y-6">
          {/* Profile Picture */}
          <div className="flex flex-col items-center">
            <div className="relative">
              <div className="w-24 h-24 rounded-full bg-gray-800 flex items-center justify-center overflow-hidden">
                {profileImage ? (
                  <img src={profileImage} alt="Profile" className="w-full h-full object-cover" />
                ) : (
                  <User size={40} className="text-gray-400" />
                )}
              </div>
              <label 
                htmlFor="profile-upload"
                className="absolute bottom-0 right-0 p-2 bg-blue-500 rounded-full cursor-pointer hover:bg-blue-600 transition-colors"
              >
                <Camera size={16} />
              </label>
              <input 
                type="file"
                id="profile-upload"
                className="hidden"
                accept="image/*"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) {
                    const reader = new FileReader();
                    reader.onload = () => {
                      setProfileImage(reader.result as string);
                    };
                    reader.readAsDataURL(file);
                  }
                }}
              />
            </div>
          </div>

          {/* Contact Information */}
          <div className="space-y-4">
            <div>
              <label className="text-sm text-gray-400 block mb-2">Full Name</label>
              <input
                type="text"
                className="w-full bg-[#252525] text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Enter your name"
              />
            </div>
            <div>
              <label className="text-sm text-gray-400 block mb-2">Email</label>
              <input
                type="email"
                className="w-full bg-[#252525] text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Enter your email"
              />
            </div>
            <div>
              <label className="text-sm text-gray-400 block mb-2">Phone</label>
              <input
                type="tel"
                className="w-full bg-[#252525] text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Enter your phone number"
              />
            </div>
          </div>

          {/* Save Button */}
          <button className="w-full bg-blue-600 text-white py-3 rounded-lg font-medium hover:bg-blue-700 active:bg-blue-800 transition-colors">
            Save Changes
          </button>
        </div>
      </div>
    </div>
  );
}

function NotificationsModal({ onClose }: { onClose: () => void }) {
  const [notifications, setNotifications] = useState({
    loanReminders: true,
    paymentDue: true,
    newTransactions: true,
    marketingUpdates: false,
  });

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[#1E1E1E] w-full max-w-md rounded-lg overflow-hidden">
        <div className="p-4 border-b border-gray-800 flex items-center">
          <button 
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-gray-800 active:bg-gray-700 transition-colors"
          >
            <ArrowLeft size={18} />
          </button>
          <h3 className="text-lg font-medium ml-3">Notification Settings</h3>
        </div>
        
        <div className="p-4 space-y-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">Loan Due Reminders</p>
                <p className="text-sm text-gray-400">Get notified about upcoming loan payments</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={notifications.loanReminders}
                  onChange={(e) => setNotifications(prev => ({
                    ...prev,
                    loanReminders: e.target.checked
                  }))}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">Payment Due Alerts</p>
                <p className="text-sm text-gray-400">Notifications for upcoming payments</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={notifications.paymentDue}
                  onChange={(e) => setNotifications(prev => ({
                    ...prev,
                    paymentDue: e.target.checked
                  }))}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">New Transactions</p>
                <p className="text-sm text-gray-400">Get notified about new transactions</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={notifications.newTransactions}
                  onChange={(e) => setNotifications(prev => ({
                    ...prev,
                    newTransactions: e.target.checked
                  }))}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">Marketing Updates</p>
                <p className="text-sm text-gray-400">Receive promotional offers and updates</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={notifications.marketingUpdates}
                  onChange={(e) => setNotifications(prev => ({
                    ...prev,
                    marketingUpdates: e.target.checked
                  }))}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>
          </div>

          {/* Save Button */}
          <button className="w-full bg-blue-600 text-white py-3 rounded-lg font-medium hover:bg-blue-700 active:bg-blue-800 transition-colors">
            Save Preferences
          </button>
        </div>
      </div>
    </div>
  );
}

function PrivacySettingsModal({ onClose }: { onClose: () => void }) {
  const [privacySettings, setPrivacySettings] = useState({
    dataSharing: false,
    analytics: true,
    marketing: false,
  });

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[#1E1E1E] w-full max-w-md rounded-lg overflow-hidden">
        <div className="p-4 border-b border-gray-800 flex items-center">
          <button 
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-gray-800 active:bg-gray-700 transition-colors"
          >
            <ArrowLeft size={18} />
          </button>
          <h3 className="text-lg font-medium ml-3">Privacy Settings</h3>
        </div>
        
        <div className="p-4 space-y-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">Data Sharing</p>
                <p className="text-sm text-gray-400">Share data with third parties</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={privacySettings.dataSharing}
                  onChange={(e) => setPrivacySettings(prev => ({
                    ...prev,
                    dataSharing: e.target.checked
                  }))}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">Analytics</p>
                <p className="text-sm text-gray-400">Help improve our services</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={privacySettings.analytics}
                  onChange={(e) => setPrivacySettings(prev => ({
                    ...prev,
                    analytics: e.target.checked
                  }))}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">Marketing</p>
                <p className="text-sm text-gray-400">Receive personalized offers</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={privacySettings.marketing}
                  onChange={(e) => setPrivacySettings(prev => ({
                    ...prev,
                    marketing: e.target.checked
                  }))}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>
          </div>

          {/* Data Export */}
          <div className="p-4 bg-[#252525] rounded-lg">
            <h4 className="font-medium mb-2">Export Your Data</h4>
            <p className="text-sm text-gray-400 mb-3">Download a copy of your personal data</p>
            <button className="w-full bg-blue-600 text-white py-2 rounded-lg font-medium hover:bg-blue-700 active:bg-blue-800 transition-colors">
              Request Data Export
            </button>
          </div>

          {/* Save Button */}
          <button className="w-full bg-blue-600 text-white py-3 rounded-lg font-medium hover:bg-blue-700 active:bg-blue-800 transition-colors">
            Save Settings
          </button>
        </div>
      </div>
    </div>
  );
}

function LoanTrackerModal({ onClose }: { onClose: () => void }) {
  const [loans] = useState<Loan[]>([
    {
      id: '1',
      name: 'Personal Loan',
      amount: 50000,
      dueDate: '2024-03-15',
      interestRate: 12.5,
      status: 'active'
    },
    {
      id: '2',
      name: 'Business Loan',
      amount: 100000,
      dueDate: '2024-04-01',
      interestRate: 10.0,
      status: 'active'
    }
  ]);

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[#1E1E1E] w-full max-w-md rounded-lg overflow-hidden">
        <div className="p-4 border-b border-gray-800 flex items-center">
          <button 
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-gray-800 active:bg-gray-700 transition-colors"
          >
            <ArrowLeft size={18} />
          </button>
          <h3 className="text-lg font-medium ml-3">Loan Tracker</h3>
        </div>
        
        <div className="p-4 space-y-6">
          {/* Active Loans */}
          <div className="space-y-4">
            <h4 className="font-medium">Active Loans</h4>
            {loans.map(loan => (
              <div key={loan.id} className="bg-[#252525] p-4 rounded-lg space-y-3">
                <div className="flex items-center justify-between">
                  <h5 className="font-medium">{loan.name}</h5>
                  <span className="text-sm px-2 py-1 bg-blue-500/20 text-blue-500 rounded-full">
                    Active
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <p className="text-gray-400">Amount</p>
                    <p className="font-medium">₹{loan.amount.toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-gray-400">Interest Rate</p>
                    <p className="font-medium">{loan.interestRate}%</p>
                  </div>
                  <div>
                    <p className="text-gray-400">Due Date</p>
                    <p className="font-medium">{new Date(loan.dueDate).toLocaleDateString()}</p>
                  </div>
                  <div>
                    <p className="text-gray-400">Days Left</p>
                    <p className="font-medium text-yellow-500">
                      {Math.ceil((new Date(loan.dueDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))} days
                    </p>
                  </div>
                </div>
                <button className="w-full bg-blue-600 text-white py-2 rounded-lg font-medium hover:bg-blue-700 active:bg-blue-800 transition-colors">
                  Make Payment
                </button>
              </div>
            ))}
          </div>

          {/* Add New Loan */}
          <button className="w-full bg-[#252525] text-white py-3 rounded-lg font-medium hover:bg-[#2A2A2A] active:bg-[#303030] transition-colors flex items-center justify-center gap-2">
            <DollarSign size={18} />
            Add New Loan
          </button>
        </div>
      </div>
    </div>
  );
}

function GeneralSettingsModal({ onClose }: { onClose: () => void }) {
  const [theme, setTheme] = useState('dark');
  const [language, setLanguage] = useState('en');

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[#1E1E1E] w-full max-w-md rounded-lg overflow-hidden">
        <div className="p-4 border-b border-gray-800 flex items-center">
          <button 
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-gray-800 active:bg-gray-700 transition-colors"
          >
            <ArrowLeft size={18} />
          </button>
          <h3 className="text-lg font-medium ml-3">General Settings</h3>
        </div>
        
        <div className="p-4 space-y-6">
          {/* Theme Selection */}
          <div>
            <label className="text-sm text-gray-400 block mb-2">Theme</label>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setTheme('light')}
                className={`p-3 rounded-lg flex items-center justify-center gap-2 transition-colors ${
                  theme === 'light' 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-[#252525] hover:bg-[#2A2A2A]'
                }`}
              >
                <Sun size={18} />
                Light
              </button>
              <button
                onClick={() => setTheme('dark')}
                className={`p-3 rounded-lg flex items-center justify-center gap-2 transition-colors ${
                  theme === 'dark' 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-[#252525] hover:bg-[#2A2A2A]'
                }`}
              >
                <Moon size={18} />
                Dark
              </button>
            </div>
          </div>

          {/* Language Selection */}
          <div>
            <label className="text-sm text-gray-400 block mb-2">Language</label>
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value)}
              className="w-full bg-[#252525] text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="en">English</option>
              <option value="hi">Hindi</option>
              <option value="gu">Gujarati</option>
              <option value="mr">Marathi</option>
            </select>
          </div>

          {/* App Info */}
          <div className="bg-[#252525] p-4 rounded-lg space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-400">Version</span>
              <span className="text-sm">2.1.0</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-400">Build</span>
              <span className="text-sm">2024.02.15</span>
            </div>
          </div>

          {/* Support */}
          <button className="w-full bg-[#252525] text-white py-3 rounded-lg font-medium hover:bg-[#2A2A2A] active:bg-[#303030] transition-colors flex items-center justify-center gap-2">
            <HelpCircle size={18} />
            Contact Support
          </button>

          {/* Save Button */}
          <button className="w-full bg-blue-600 text-white py-3 rounded-lg font-medium hover:bg-blue-700 active:bg-blue-800 transition-colors">
            Save Changes
          </button>
        </div>
      </div>
    </div>
  );
}

function Settings({ onClose, onNavigateToPaymentHistory, onNavigateToChopdaCalendar }: SettingsProps) {
  const [showAccountDetails, setShowAccountDetails] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showPrivacySettings, setShowPrivacySettings] = useState(false);
  const [showLoanTracker, setShowLoanTracker] = useState(false);
  const [showGeneralSettings, setShowGeneralSettings] = useState(false);

  const settingsOptions = [
    { icon: History, label: 'Payment History', onClick: onNavigateToPaymentHistory },
    { icon: Calendar, label: 'Chopda Calendar', onClick: onNavigateToChopdaCalendar },
    { icon: User, label: 'Account Details', onClick: () => setShowAccountDetails(true) },
    { icon: CreditCard, label: 'Loan Tracker', onClick: () => setShowLoanTracker(true) },
    { icon: Bell, label: 'Notifications', onClick: () => setShowNotifications(true) },
    { icon: Lock, label: 'Privacy Settings', onClick: () => setShowPrivacySettings(true) },
    { icon: SettingsIcon, label: 'General Settings', onClick: () => setShowGeneralSettings(true) },
  ];

  return (
    <div className="fixed inset-0 bg-[#121212] text-white p-4">
      {/* Header */}
      <div className="flex items-center mb-8">
        <button 
          onClick={onClose}
          className="p-2 -ml-2 rounded-full hover:bg-gray-800 active:bg-gray-700 transition-colors"
          aria-label="Back"
        >
          <ArrowLeft size={24} />
        </button>
        <h1 className="text-xl font-medium text-center flex-1 -ml-8">
          Settings
        </h1>
      </div>

      {/* Settings Options */}
      <div className="space-y-2">
        {settingsOptions.map((option, index) => (
          <button
            key={index}
            onClick={option.onClick}
            className="w-full flex items-center justify-between p-4 bg-[#1E1E1E] rounded-lg hover:bg-[#252525] active:bg-[#2A2A2A] transition-colors"
          >
            <div className="flex items-center gap-3">
              <option.icon size={20} className="text-gray-400" />
              <span>{option.label}</span>
            </div>
            <ChevronRight size={20} className="text-gray-400" />
          </button>
        ))}
      </div>

      {/* Logout Button */}
      <button className="w-full flex items-center justify-center gap-2 mt-8 p-4 bg-red-500/10 text-red-500 rounded-lg hover:bg-red-500/20 active:bg-red-500/30 transition-colors">
        <LogOut size={20} />
        <span>Logout</span>
      </button>

      {/* Modals */}
      {showAccountDetails && <AccountDetailsModal onClose={() => setShowAccountDetails(false)} />}
      {showNotifications && <NotificationsModal onClose={() => setShowNotifications(false)} />}
      {showPrivacySettings && <PrivacySettingsModal onClose={() => setShowPrivacySettings(false)} />}
      {showLoanTracker && <LoanTrackerModal onClose={() => setShowLoanTracker(false)} />}
      {showGeneralSettings && <GeneralSettingsModal onClose={() => setShowGeneralSettings(false)} />}
    </div>
  );
}

export default Settings;