import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Search, 
  Download, 
  Filter, 
  Users, 
  Receipt, 
  Calculator,
  Calendar,
  TrendingUp,
  Mail,
  Camera,
  FileText,
  AlertTriangle,
  X,
  Upload
} from 'lucide-react';

interface ReportsProps {
  onClose: () => void;
}

interface TabContentProps {
  activeTab: string;
}

function ScanBillModal({ onClose }: { onClose: () => void }) {
  const [isDragging, setIsDragging] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = () => {
        setPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = () => {
        setPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[#1E1E1E] w-full max-w-md rounded-lg overflow-hidden">
        <div className="p-4 border-b border-gray-800 flex justify-between items-center">
          <h3 className="text-lg font-medium">Scan Bill</h3>
          <button 
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-gray-800 active:bg-gray-700 transition-colors"
          >
            <X size={18} />
          </button>
        </div>
        
        <div className="p-4">
          {preview ? (
            <div className="space-y-4">
              <div className="relative aspect-[3/4] rounded-lg overflow-hidden">
                <img 
                  src={preview} 
                  alt="Bill preview" 
                  className="w-full h-full object-cover"
                />
                <button 
                  onClick={() => setPreview(null)}
                  className="absolute top-2 right-2 p-1.5 rounded-full bg-black/50 hover:bg-black/70 transition-colors"
                >
                  <X size={18} />
                </button>
              </div>
              <button className="w-full bg-blue-600 text-white py-3 rounded-lg font-medium hover:bg-blue-700 active:bg-blue-800 transition-colors">
                Process Bill
              </button>
            </div>
          ) : (
            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              className={`
                border-2 border-dashed rounded-lg p-8
                ${isDragging ? 'border-blue-500 bg-blue-500/10' : 'border-gray-700'}
                transition-colors
              `}
            >
              <div className="flex flex-col items-center gap-4">
                <div className="p-4 bg-blue-500/10 rounded-full">
                  <Upload size={32} className="text-blue-500" />
                </div>
                <div className="text-center">
                  <p className="font-medium">Drag & Drop or Click to Upload</p>
                  <p className="text-sm text-gray-400 mt-1">Supports JPG, PNG up to 10MB</p>
                </div>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleFileInput}
                  className="hidden"
                  id="bill-upload"
                />
                <label
                  htmlFor="bill-upload"
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg cursor-pointer hover:bg-blue-700 active:bg-blue-800 transition-colors"
                >
                  Choose File
                </label>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function ExportModal({ onClose }: { onClose: () => void }) {
  const [format, setFormat] = useState('pdf');
  const [dateRange, setDateRange] = useState('all');
  const [isExporting, setIsExporting] = useState(false);

  const handleExport = () => {
    setIsExporting(true);
    // Simulate export process
    setTimeout(() => {
      setIsExporting(false);
      onClose();
    }, 2000);
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[#1E1E1E] w-full max-w-md rounded-lg overflow-hidden">
        <div className="p-4 border-b border-gray-800 flex justify-between items-center">
          <h3 className="text-lg font-medium">Export Report</h3>
          <button 
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-gray-800 active:bg-gray-700 transition-colors"
          >
            <X size={18} />
          </button>
        </div>
        
        <div className="p-4 space-y-4">
          <div>
            <label className="text-sm text-gray-400 block mb-2">Format</label>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setFormat('pdf')}
                className={`p-3 rounded-lg flex items-center justify-center gap-2 transition-colors ${
                  format === 'pdf' 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-[#252525] hover:bg-[#2A2A2A]'
                }`}
              >
                <FileText size={18} />
                PDF
              </button>
              <button
                onClick={() => setFormat('csv')}
                className={`p-3 rounded-lg flex items-center justify-center gap-2 transition-colors ${
                  format === 'csv' 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-[#252525] hover:bg-[#2A2A2A]'
                }`}
              >
                <Receipt size={18} />
                CSV
              </button>
            </div>
          </div>

          <div>
            <label className="text-sm text-gray-400 block mb-2">Date Range</label>
            <select
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value)}
              className="w-full bg-[#252525] text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">All Time</option>
              <option value="today">Today</option>
              <option value="week">This Week</option>
              <option value="month">This Month</option>
              <option value="year">This Year</option>
              <option value="custom">Custom Range</option>
            </select>
          </div>

          <button
            onClick={handleExport}
            disabled={isExporting}
            className="w-full bg-blue-600 text-white py-3 rounded-lg font-medium hover:bg-blue-700 active:bg-blue-800 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {isExporting ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Exporting...
              </>
            ) : (
              <>
                <Download size={18} />
                Export Report
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}

function TabContent({ activeTab }: TabContentProps) {
  const [showScanModal, setShowScanModal] = useState(false);
  
  const graphData = [
    { date: 'Jan 1', value: 1500 },
    { date: 'Jan 8', value: 2800 },
    { date: 'Jan 15', value: 1800 },
    { date: 'Jan 22', value: 3200 },
    { date: 'Jan 30', value: 2500 }
  ];

  const maxValue = Math.max(...graphData.map(d => d.value));

  const renderAllTab = () => (
    <div className="space-y-6">
      {/* Filters */}
      <div className="bg-[#1E1E1E] p-4 rounded-lg">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-medium">Filters</h3>
          <button className="flex items-center gap-2 text-blue-500">
            <Filter size={16} />
            <span className="text-sm">Apply Filters</span>
          </button>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <button className="p-2 bg-[#252525] rounded-lg text-sm hover:bg-[#2A2A2A] transition-colors">
            Date Range
          </button>
          <button className="p-2 bg-[#252525] rounded-lg text-sm hover:bg-[#2A2A2A] transition-colors">
            Amount
          </button>
          <button className="p-2 bg-[#252525] rounded-lg text-sm hover:bg-[#2A2A2A] transition-colors">
            Category
          </button>
          <button className="p-2 bg-[#252525] rounded-lg text-sm hover:bg-[#2A2A2A] transition-colors">
            Transaction Type
          </button>
        </div>
      </div>

      {/* Summary Statistics */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-[#1E1E1E] p-4 rounded-lg">
          <p className="text-sm text-gray-400">Total Income</p>
          <p className="text-xl font-bold text-green-500">₹45,230</p>
        </div>
        <div className="bg-[#1E1E1E] p-4 rounded-lg">
          <p className="text-sm text-gray-400">Total Expenses</p>
          <p className="text-xl font-bold text-red-500">₹32,180</p>
        </div>
        <div className="bg-[#1E1E1E] p-4 rounded-lg">
          <p className="text-sm text-gray-400">Net Profit</p>
          <p className="text-xl font-bold text-blue-500">₹13,050</p>
        </div>
        <div className="bg-[#1E1E1E] p-4 rounded-lg">
          <p className="text-sm text-gray-400">Daily Average</p>
          <p className="text-xl font-bold">₹1,073</p>
        </div>
      </div>

      {/* Graph Component */}
      <div className="bg-[#1E1E1E] rounded-lg p-4">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h3 className="font-medium">Total Sales</h3>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold">₹2,184.12</span>
              <span className="text-sm text-green-500">+14%</span>
            </div>
            <p className="text-sm text-gray-400">Last 30 days</p>
          </div>
        </div>

        {/* Graph */}
        <div className="relative h-40 mt-6">
          <div className="absolute inset-0 flex flex-col justify-between">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="w-full h-px bg-gray-800" />
            ))}
          </div>

          <div className="absolute inset-0 flex items-end">
            <svg className="w-full h-full" preserveAspectRatio="none">
              <defs>
                <linearGradient id="line-gradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="rgb(59, 130, 246)" stopOpacity="0.5" />
                  <stop offset="100%" stopColor="rgb(59, 130, 246)" stopOpacity="0" />
                </linearGradient>
              </defs>
              
              <path
                d={`
                  M 0 ${100 - (graphData[0].value / maxValue) * 100}
                  ${graphData.map((point, i) => {
                    const x = (i / (graphData.length - 1)) * 100;
                    const y = 100 - (point.value / maxValue) * 100;
                    return `L ${x} ${y}`;
                  }).join(' ')}
                  L 100 100 L 0 100 Z
                `}
                fill="url(#line-gradient)"
                className="transition-all duration-300"
              />

              <path
                d={`
                  M 0 ${100 - (graphData[0].value / maxValue) * 100}
                  ${graphData.map((point, i) => {
                    const x = (i / (graphData.length - 1)) * 100;
                    const y = 100 - (point.value / maxValue) * 100;
                    return `L ${x} ${y}`;
                  }).join(' ')}
                `}
                fill="none"
                stroke="rgb(59, 130, 246)"
                strokeWidth="2"
                className="transition-all duration-300"
              />

              {graphData.map((point, i) => {
                const x = (i / (graphData.length - 1)) * 100;
                const y = 100 - (point.value / maxValue) * 100;
                return (
                  <circle
                    key={i}
                    cx={`${x}%`}
                    cy={`${y}%`}
                    r="4"
                    fill="rgb(59, 130, 246)"
                    className="transition-all duration-300"
                  />
                );
              })}
            </svg>
          </div>

          <div className="absolute bottom-0 left-0 right-0 flex justify-between mt-2">
            {graphData.map((point, i) => (
              <span key={i} className="text-xs text-gray-400">
                {point.date.split(' ')[1]}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );

  const renderCustomerTab = () => (
    <div className="space-y-6">
      {/* Customer Segments */}
      <div className="bg-[#1E1E1E] p-4 rounded-lg">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-medium">Customer Segments</h3>
          <Users size={20} className="text-gray-400" />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="p-3 bg-[#252525] rounded-lg">
            <p className="text-sm text-gray-400">Premium</p>
            <p className="text-lg font-bold">24</p>
          </div>
          <div className="p-3 bg-[#252525] rounded-lg">
            <p className="text-sm text-gray-400">Regular</p>
            <p className="text-lg font-bold">156</p>
          </div>
        </div>
      </div>

      {/* Customer Reports */}
      <div className="space-y-4">
        <div className="bg-[#1E1E1E] p-4 rounded-lg flex items-center justify-between">
          <div>
            <h3 className="font-medium mb-1">Customer Profiles</h3>
            <p className="text-sm text-gray-400">View detailed customer information</p>
          </div>
          <button className="p-2 bg-[#252525] rounded-lg hover:bg-[#2A2A2A]">
            <Users size={18} />
          </button>
        </div>

        <div className="bg-[#1E1E1E] p-4 rounded-lg flex items-center justify-between">
          <div>
            <h3 className="font-medium mb-1">Sales Tracking</h3>
            <p className="text-sm text-gray-400">Monitor sales performance</p>
          </div>
          <button className="p-2 bg-[#252525] rounded-lg hover:bg-[#2A2A2A]">
            <TrendingUp size={18} />
          </button>
        </div>

        <div className="bg-[#1E1E1E] p-4 rounded-lg flex items-center justify-between">
          <div>
            <h3 className="font-medium mb-1">Communication Center</h3>
            <p className="text-sm text-gray-400">Send messages to customers</p>
          </div>
          <button className="p-2 bg-[#252525] rounded-lg hover:bg-[#2A2A2A]">
            <Mail size={18} />
          </button>
        </div>
      </div>
    </div>
  );

  const renderBillsTab = () => (
    <div className="space-y-6">
      {/* Quick Actions */}
      <div className="grid grid-cols-2 gap-4">
        <button 
          onClick={() => setShowScanModal(true)}
          className="bg-[#1E1E1E] p-4 rounded-lg flex flex-col items-center gap-2 hover:bg-[#252525] active:bg-[#2A2A2A] transition-colors"
        >
          <Camera size={24} className="text-blue-500" />
          <span className="text-sm">Scan Bill</span>
        </button>
        <button className="bg-[#1E1E1E] p-4 rounded-lg flex flex-col items-center gap-2 hover:bg-[#252525] active:bg-[#2A2A2A] transition-colors">
          <FileText size={24} className="text-blue-500" />
          <span className="text-sm">Create Invoice</span>
        </button>
      </div>

      {/* Bill Management */}
      <div className="bg-[#1E1E1E] p-4 rounded-lg">
        <h3 className="font-medium mb-4">Recent Bills</h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between p-3 bg-[#252525] rounded-lg">
            <div>
              <p className="font-medium">Bill #1234</p>
              <p className="text-sm text-gray-400">Due in 3 days</p>
            </div>
            <p className="text-lg font-bold">₹2,500</p>
          </div>
          <div className="flex items-center justify-between p-3 bg-[#252525] rounded-lg">
            <div>
              <p className="font-medium">Bill #1235</p>
              <p className="text-sm text-gray-400">Due in 5 days</p>
            </div>
            <p className="text-lg font-bold">₹1,800</p>
          </div>
        </div>
      </div>

      {/* Expense Categories */}
      <div className="bg-[#1E1E1E] p-4 rounded-lg">
        <h3 className="font-medium mb-4">Expense Categories</h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span>Utilities</span>
            <span className="text-blue-500">35%</span>
          </div>
          <div className="flex items-center justify-between">
            <span>Supplies</span>
            <span className="text-blue-500">28%</span>
          </div>
          <div className="flex items-center justify-between">
            <span>Services</span>
            <span className="text-blue-500">22%</span>
          </div>
          <div className="flex items-center justify-between">
            <span>Others</span>
            <span className="text-blue-500">15%</span>
          </div>
        </div>
      </div>

      {showScanModal && <ScanBillModal onClose={() => setShowScanModal(false)} />}
    </div>
  );

  const renderGSTTab = () => (
    <div className="space-y-6">
      {/* GST Summary */}
      <div className="bg-[#1E1E1E] p-4 rounded-lg">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-medium">GST Summary</h3>
          <Calculator size={20} className="text-gray-400" />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="p-3 bg-[#252525] rounded-lg">
            <p className="text-sm text-gray-400">Input Tax</p>
            <p className="text-lg font-bold">₹12,450</p>
          </div>
          <div className="p-3 bg-[#252525] rounded-lg">
            <p className="text-sm text-gray-400">Output Tax</p>
            <p className="text-lg font-bold">₹15,680</p>
          </div>
        </div>
      </div>

      {/* GST Returns */}
      <div className="bg-[#1E1E1E] p-4 rounded-lg">
        <h3 className="font-medium mb-4">GST Returns</h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between p-3 bg-[#252525] rounded-lg">
            <div className="flex items-center gap-3">
              <Calendar size={18} className="text-gray-400" />
              <div>
                <p className="font-medium">GSTR-1</p>
                <p className="text-sm text-gray-400">Due on 11th Feb</p>
              </div>
            </div>
            <button className="px-3 py-1 bg-blue-500 rounded-lg text-sm">
              Prepare
            </button>
          </div>
          <div className="flex items-center justify-between p-3 bg-[#252525] rounded-lg">
            <div className="flex items-center gap-3">
              <Calendar size={18} className="text-gray-400" />
              <div>
                <p className="font-medium">GSTR-3B</p>
                <p className="text-sm text-gray-400">Due on 20th Feb</p>
              </div>
            </div>
            <button className="px-3 py-1 bg-blue-500 rounded-lg text-sm">
              Prepare
            </button>
          </div>
        </div>
      </div>

      {/* Compliance Alerts */}
      <div className="bg-[#1E1E1E] p-4 rounded-lg">
        <div className="flex items-center gap-2 mb-4">
          <AlertTriangle size={20} className="text-yellow-500" />
          <h3 className="font-medium">Compliance Alerts</h3>
        </div>
        <div className="space-y-3">
          <div className="p-3 bg-[#252525] rounded-lg">
            <p className="text-sm">GST rate change for textile items effective from Feb 1st</p>
          </div>
          <div className="p-3 bg-[#252525] rounded-lg">
            <p className="text-sm">New e-invoicing requirements for B2B transactions</p>
          </div>
        </div>
      </div>
    </div>
  );

  switch (activeTab) {
    case 'All':
      return renderAllTab();
    case 'Customer':
      return renderCustomerTab();
    case 'Bills':
      return renderBillsTab();
    case 'GST':
      return renderGSTTab();
    default:
      return renderAllTab();
  }
}

function Reports({ onClose }: ReportsProps) {
  const [showExportModal, setShowExportModal] = useState(false);
  const [activeTab, setActiveTab] = useState('All');
  const tabs = ['All', 'Customer', 'Bills', 'GST', 'Day-wise'];

  return (
    <div className="fixed inset-0 bg-[#121212] text-white flex flex-col max-w-md mx-auto">
      {/* Header */}
      <div className="p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button 
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-gray-800 active:bg-gray-700 transition-colors"
          >
            <ArrowLeft size={18} />
          </button>
          <h1 className="text-xl font-bold">Reports</h1>
        </div>
        <button className="p-1.5 rounded-full hover:bg-gray-800 active:bg-gray-700 transition-colors">
          <Search size={18} />
        </button>
      </div>

      {/* Tabs */}
      <div className="flex gap-4 px-4 overflow-x-auto hide-scrollbar border-b border-gray-800">
        {tabs.map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`pb-2 px-1 whitespace-nowrap ${
              activeTab === tab
                ? 'border-b-2 border-blue-500 text-blue-500 font-medium'
                : 'text-gray-400'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto p-4">
        <TabContent activeTab={activeTab} />
      </div>

      {/* Export Button */}
      <div className="p-4 border-t border-gray-800">
        <button 
          onClick={() => setShowExportModal(true)}
          className="w-full bg-[#1E1E1E] text-white py-3 rounded-lg font-medium hover:bg-[#252525] active:bg-[#2A2A2A] transition-colors flex items-center justify-center gap-2"
        >
          <Download size={18} />
          Export Report
        </button>
      </div>

      {showExportModal && <ExportModal onClose={() => setShowExportModal(false)} />}

      <style>{`
        .hide-scrollbar::-webkit-scrollbar {
          display: none;
        }
        .hide-scrollbar {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
      `}</style>
    </div>
  );
}

export default Reports;