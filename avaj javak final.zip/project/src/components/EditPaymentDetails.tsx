import React, { useState } from 'react';
import { ArrowLeft, Calendar } from 'lucide-react';

interface EditPaymentDetailsProps {
  onClose: () => void;
  onSave: (details: {
    amount: string;
    method: string;
    date: string;
  }) => void;
}

function EditPaymentDetails({ onClose, onSave }: EditPaymentDetailsProps) {
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState('bank');
  const [date, setDate] = useState('');

  const handleSave = () => {
    onSave({ amount, method, date });
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-[#121212] text-white p-4">
      {/* Header */}
      <div className="flex items-center mb-8">
        <button 
          onClick={onClose}
          className="p-2 -ml-2 rounded-full hover:bg-gray-800 active:bg-gray-700 transition-colors"
          aria-label="Back"
        >
          <ArrowLeft size={24} />
        </button>
        <h1 className="text-xl font-medium text-center flex-1 -ml-8">
          Edit Payment Details
        </h1>
      </div>

      {/* Main Form */}
      <div className="flex flex-col gap-6 mb-8">
        {/* Amount Input */}
        <div className="space-y-2">
          <label className="text-sm text-gray-400">Amount</label>
          <input
            type="text"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="₹0.00"
            className="w-full bg-[#1E1E1E] text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        {/* Payment Method */}
        <div className="space-y-2">
          <label className="text-sm text-gray-400">Payment Method</label>
          <select
            value={method}
            onChange={(e) => setMethod(e.target.value)}
            className="w-full bg-[#1E1E1E] text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 appearance-none"
          >
            <option value="bank">Bank Transfer</option>
            <option value="upi">UPI</option>
            <option value="cash">Cash</option>
          </select>
        </div>

        {/* Date Input */}
        <div className="space-y-2">
          <label className="text-sm text-gray-400">Payment Date</label>
          <div className="relative">
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full bg-[#1E1E1E] text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <Calendar className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex flex-col gap-4">
        <button
          onClick={handleSave}
          className="w-full bg-blue-600 text-white py-3 rounded-lg font-medium hover:bg-blue-700 active:bg-blue-800 transition-colors"
        >
          Save
        </button>
        
        <button
          onClick={onClose}
          className="w-full bg-gray-700 text-white py-3 rounded-lg font-medium hover:bg-gray-600 active:bg-gray-500 transition-colors"
        >
          Cancel
        </button>
      </div>

      {/* Footer */}
      <button className="w-full text-center text-blue-400 mt-6 py-2 hover:text-blue-300 transition-colors">
        Add a Note to this Payment
      </button>
    </div>
  );
}

export default EditPaymentDetails;