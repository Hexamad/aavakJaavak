import React, { useState } from 'react';
import { ArrowLeft, ArrowRight, Calendar, FileText, BarChart2, Settings as SettingsIcon, Plus, CircleDollarSign } from 'lucide-react';

interface Transaction {
  id: number;
  type: 'credit' | 'debit';
  amount: number;
  time: string;
  description: string;
}

interface ChopdaCalendarProps {
  onClose: () => void;
  onNavigateToReports: () => void;
}

function ChopdaCalendar({ onClose, onNavigateToReports }: ChopdaCalendarProps) {
  const [currentMonth] = useState('January 2025');
  const [selectedDate] = useState(5);
  
  const timeSlots = Array.from({ length: 24 }, (_, i) => {
    const hour = i % 12 || 12;
    const ampm = i < 12 ? 'AM' : 'PM';
    return `${hour}:00 ${ampm}`;
  });

  const transactions: Transaction[] = [
    {
      id: 1,
      type: 'credit',
      amount: 50,
      time: '12:30 PM',
      description: 'Transaction 1'
    },
    {
      id: 2,
      type: 'debit',
      amount: 30,
      time: '1:45 PM',
      description: 'Transaction 2'
    }
  ];

  const daysOfWeek = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
  const totalDays = 31;
  const weeks = Math.ceil(totalDays / 7);

  // Calculate the starting day offset (0 = Sunday, 1 = Monday, etc.)
  const startingDayOffset = 0; // Assuming month starts on Sunday

  return (
    <div className="fixed inset-0 bg-[#121212] text-white flex flex-col max-w-md mx-auto">
      {/* Header */}
      <div className="p-3 flex items-center justify-between border-b border-gray-800">
        <div className="flex items-center gap-3">
          <button 
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-gray-800 active:bg-gray-700 transition-colors"
          >
            <ArrowLeft size={18} />
          </button>
          <h1 className="text-lg font-bold">Chopda Calendar</h1>
        </div>
        <button className="p-1.5 rounded-full hover:bg-gray-800 active:bg-gray-700 transition-colors">
          <Plus size={18} />
        </button>
      </div>

      {/* Calendar */}
      <div className="p-3 bg-[#1E1E1E] border-b border-gray-800">
        <div className="flex items-center justify-between mb-3">
          <button className="p-1 hover:bg-gray-700 rounded-full">
            <ArrowLeft size={14} />
          </button>
          <span className="text-sm font-medium">{currentMonth}</span>
          <button className="p-1 hover:bg-gray-700 rounded-full">
            <ArrowRight size={14} />
          </button>
        </div>
        
        <div className="grid grid-cols-7 gap-1 mb-1">
          {daysOfWeek.map((day, index) => (
            <div key={`header-${day}-${index}`} className="text-center text-xs text-gray-400">
              {day}
            </div>
          ))}
        </div>
        
        <div className="grid grid-cols-7 gap-1">
          {Array.from({ length: weeks * 7 }).map((_, index) => {
            const dayNumber = index - startingDayOffset + 1;
            const isValidDay = dayNumber > 0 && dayNumber <= totalDays;
            
            if (!isValidDay) {
              return <div key={`empty-${index}`} className="aspect-square" />;
            }

            return (
              <button
                key={`day-${dayNumber}`}
                className={`
                  aspect-square rounded-full flex items-center justify-center text-xs
                  ${dayNumber === selectedDate ? 'bg-green-500 text-white' : 'hover:bg-gray-700'}
                `}
              >
                {dayNumber}
              </button>
            );
          })}
        </div>
      </div>

      {/* Timeline */}
      <div className="flex-1 overflow-auto">
        {timeSlots.map((time, index) => (
          <div key={`timeslot-${index}`} className="flex items-start py-2 px-3">
            <div className="w-16 text-xs text-gray-400">{time}</div>
            <div className="flex-1 border-l border-gray-700 pl-3 min-h-[32px]">
              {transactions.map(transaction => {
                const [transactionHour] = transaction.time.split(':');
                const [timeSlotHour] = time.split(':');
                if (transactionHour === timeSlotHour) {
                  return (
                    <div
                      key={`transaction-${transaction.id}`}
                      className="bg-[#1E1E1E] p-2 rounded-lg mb-2 cursor-pointer hover:bg-[#252525]"
                    >
                      <div className="flex items-center gap-2">
                        <CircleDollarSign size={16} className={transaction.type === 'credit' ? 'text-green-500' : 'text-red-500'} />
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <span className="text-xs">{transaction.description}</span>
                            <span className={`text-xs ${
                              transaction.type === 'credit' ? 'text-green-500' : 'text-red-500'
                            }`}>
                              {transaction.type === 'credit' ? '+' : '-'}₹{transaction.amount}
                            </span>
                          </div>
                          <span className="text-xs text-gray-400">{transaction.time}</span>
                        </div>
                      </div>
                    </div>
                  );
                }
                return null;
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Summary */}
      <div className="bg-[#1E1E1E] border-t border-gray-800">
        <div className="grid grid-cols-2 gap-3 p-3">
          <div>
            <div className="text-green-500 text-base font-bold">₹200</div>
            <div className="text-xs text-gray-400 flex items-center gap-1">
              Credits <span className="text-green-500">+20%</span>
            </div>
          </div>
          <div>
            <div className="text-red-500 text-base font-bold">₹150</div>
            <div className="text-xs text-gray-400 flex items-center gap-1">
              Debits <span className="text-red-500">-10%</span>
            </div>
          </div>
        </div>

        {/* Navigation Bar */}
        <div className="flex justify-around py-2 px-3 border-t border-gray-700">
          <button className="p-1.5 text-green-500 flex flex-col items-center">
            <Calendar size={18} />
            <span className="text-[10px] mt-0.5">Calendar</span>
          </button>
          <button className="p-1.5 text-gray-400 flex flex-col items-center">
            <FileText size={18} />
            <span className="text-[10px] mt-0.5">Transactions</span>
          </button>
          <button 
            className="p-1.5 text-gray-400 flex flex-col items-center"
            onClick={onNavigateToReports}
          >
            <BarChart2 size={18} />
            <span className="text-[10px] mt-0.5">Reports</span>
          </button>
          <button className="p-1.5 text-gray-400 flex flex-col items-center">
            <SettingsIcon size={18} />
            <span className="text-[10px] mt-0.5">Settings</span>
          </button>
        </div>
      </div>
    </div>
  );
}

export default ChopdaCalendar;