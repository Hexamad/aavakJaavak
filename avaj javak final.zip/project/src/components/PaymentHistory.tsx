import React, { useState } from 'react';
import { ArrowLeft, Calendar, DollarSign } from 'lucide-react';

interface PaymentHistoryProps {
  onClose: () => void;
}

function PaymentHistory({ onClose }: PaymentHistoryProps) {
  const [dateRange, setDateRange] = useState('This Month: 01 Jan - 18 Jan');

  return (
    <div className="fixed inset-0 bg-[#121212] text-white p-4">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Payment History</h1>
        <button 
          onClick={onClose}
          className="p-2 rounded-full hover:bg-gray-800 active:bg-gray-700 transition-colors"
        >
          <ArrowLeft size={24} />
        </button>
      </div>

      {/* Balance Section */}
      <div className="mb-6">
        <h2 className="text-xl font-bold mb-4">Balance</h2>
        <div className="flex items-center gap-4 mb-4">
          <div className="bg-[#1E1E1E] p-3 rounded-lg">
            <DollarSign size={24} className="text-gray-400" />
          </div>
          <div>
            <p className="text-gray-400">Balance</p>
            <p className="text-xl font-semibold">$0.00</p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <button className="bg-[#1E1E1E] py-3 px-4 rounded-lg font-medium hover:bg-[#252525] active:bg-[#2A2A2A] transition-colors">
            Settle to Bank
          </button>
          <button className="bg-[#1E1E1E] py-3 px-4 rounded-lg font-medium hover:bg-[#252525] active:bg-[#2A2A2A] transition-colors">
            Add Money
          </button>
        </div>

        <p className="text-sm text-gray-400 mt-4">
          All collections are settled to your bank account the next business day.
        </p>
      </div>

      {/* Filter Section */}
      <div className="mb-6">
        <h2 className="text-xl font-bold mb-4">Filter</h2>
        <button 
          className="w-full flex items-center gap-3 bg-[#1E1E1E] p-4 rounded-lg hover:bg-[#252525] active:bg-[#2A2A2A] transition-colors"
          onClick={() => {}}
        >
          <Calendar size={20} className="text-gray-400" />
          <div className="flex-1 text-left">
            <p>{dateRange}</p>
            <p className="text-sm text-gray-400">View all transactions</p>
          </div>
        </button>
      </div>

      {/* No Payments Section */}
      <div className="text-center">
        <div className="bg-[#1E1E1E] rounded-lg p-6 mb-4">
          <img 
            src="https://images.unsplash.com/photo-1563013544-824ae1b704d3?auto=format&fit=crop&w=800&q=80" 
            alt="No payments"
            className="w-full h-48 object-cover rounded-lg mb-4"
          />
        </div>
        <h3 className="text-xl font-bold mb-2">No payments received yet</h3>
        <p className="text-gray-400 mb-6">
          You have not received any payments for this date range.
        </p>
        <button className="bg-[#1E1E1E] py-3 px-6 rounded-lg font-medium hover:bg-[#252525] active:bg-[#2A2A2A] transition-colors">
          View Pending Money Requests
        </button>
      </div>
    </div>
  );
}

export default PaymentHistory;