import React, { useState } from 'react';
import { X } from 'lucide-react';

interface EditBusinessNameProps {
  currentName: string;
  onClose: () => void;
  onSave: (newName: string) => void;
}

function EditBusinessName({ currentName, onClose, onSave }: EditBusinessNameProps) {
  const [businessName, setBusinessName] = useState(currentName);

  const handleSave = () => {
    onSave(businessName);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-[#121212] text-white p-4">
      {/* Header */}
      <div className="flex items-center mb-8">
        <button 
          onClick={onClose}
          className="p-2 -ml-2 rounded-full hover:bg-gray-800 active:bg-gray-700 transition-colors"
          aria-label="Close"
        >
          <X size={24} />
        </button>
        <h1 className="text-xl font-medium text-center flex-1 -ml-8">
          Edit Business Name
        </h1>
      </div>

      {/* Business Name Input */}
      <div className="mb-8">
        <input
          type="text"
          value={businessName}
          onChange={(e) => setBusinessName(e.target.value)}
          className="w-full bg-[#1E1E1E] text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          placeholder="Enter business name"
        />
      </div>

      {/* Action Buttons */}
      <div className="flex flex-col gap-4">
        <button
          onClick={handleSave}
          className="w-full bg-blue-600 text-white py-3 rounded-lg font-medium hover:bg-blue-700 active:bg-blue-800 transition-colors"
        >
          Save
        </button>
        
        <button
          className="text-gray-400 py-2 hover:text-gray-300 transition-colors"
        >
          Create New Khatabook
        </button>
        
        <button
          className="text-gray-400 py-2 hover:text-gray-300 transition-colors"
        >
          Choose another book
        </button>
      </div>
    </div>
  );
}

export default EditBusinessName;